
-- =============================================
-- Author:		Douglas Ochieng
-- Create date: 28/06/2020
-- Description:	/* local gsm or sip for ivory coast*/
-- =============================================
CREATE PROCEDURE [dbo].[util_get_sip_rank] 
	--Add the parameters for the stored procedure here
	@in_called_no nvarchar(50) --line 22 from the cdr datafile
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare

	@tel_no_dial nvarchar (30)
    -- construct SQL
        BEGIN 	
		--check call type		
			BEGIN TRY
				begin
					Begin
						truncate Table pref_sip_operators
					End
				end
				begin
						if LEFT(@in_called_no, 1)='0'  -- check the next two characters if official local 
							begin
								if LEFT(@in_called_no, 2)='00' 
									begin
										set @tel_no_dial = RIGHT(@in_called_no, LEN(@in_called_no) - 2)
										insert into pref_sip_operators (PREF,AREA,UNIT_CHG,SPCODE)
										select ROW_NUMBER() OVER(ORDER BY ac.AREA,ac.UNIT_CHG ASC) as RANK,ac.AREA,ac.UNIT_CHG,ac.SPCode  from  areacode ac
										where @tel_no_dial like ac.area + '%' 
									end
								if LEFT(@in_called_no, 3)='000' -- check the next two characters local 
									begin
										set @tel_no_dial = RIGHT(@in_called_no, LEN(@in_called_no) - 3)
										insert into pref_sip_operators (PREF,AREA,UNIT_CHG,SPCODE)
										select ROW_NUMBER() OVER(ORDER BY ac.AREA,ac.UNIT_CHG ASC) as RANK,ac.AREA,ac.UNIT_CHG,ac.SPCode  from  areacode ac
										where @tel_no_dial like ac.area + '%' 
										order by ac.AREA,ac.UNIT_CHG
									end
							end								
						if LEFT(@in_called_no, 3)='800' -- check the next two characters local 
							begin
								set @tel_no_dial = RIGHT(@in_called_no, LEN(@in_called_no) - 3)
								insert into pref_sip_operators (PREF,AREA,UNIT_CHG,SPCODE)
								select ROW_NUMBER() OVER(ORDER BY ac.AREA,ac.UNIT_CHG ASC) as RANK,ac.AREA,ac.UNIT_CHG,ac.SPCode  from  areacode ac
								where @tel_no_dial like ac.area + '%' 
								order by ac.AREA,ac.UNIT_CHG
							end								
						if LEFT(@in_called_no, 1)<>'0'
							begin
								set @tel_no_dial = @in_called_no
								insert into pref_sip_operators (PREF,AREA,UNIT_CHG,SPCODE)
								select ROW_NUMBER() OVER(ORDER BY ac.AREA,ac.UNIT_CHG ASC) as RANK,ac.AREA,ac.UNIT_CHG,ac.SPCode  from  areacode ac
								where @tel_no_dial like ac.area + '%' 
								order by ac.AREA,ac.UNIT_CHG
							end								
				end
				begin
					select * from pref_sip_operators
				end
			END TRY
			BEGIN CATCH
				IF @@ERROR <> 0
				BEGIN
					DECLARE @ErrorMessage  NVARCHAR(4000)
					DECLARE @ErrorSeverity INT
					DECLARE @ErrorState    INT
   
					SELECT @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE(),
							@ErrorMessage  = ERROR_MESSAGE()

					SET NOCOUNT OFF

					RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)
				END
			END CATCH 
		END
    -- execute the SQL
	--	EXEC sp_executesql @sql
	SET NOCOUNT OFF  
	RETURN
END
go

